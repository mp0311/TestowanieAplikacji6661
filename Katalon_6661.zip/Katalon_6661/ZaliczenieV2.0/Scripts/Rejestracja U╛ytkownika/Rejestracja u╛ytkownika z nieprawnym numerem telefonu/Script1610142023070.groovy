import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

/*  Otworzenie przeglądarki i przejscie na stronę phptravels.net  */
WebUI.openBrowser(rawUrl = GlobalVariable.url)

/* Kliknięcie na MyAccount */
WebUI.click(findTestObject('Object Repository/PHPTRAVELS_Main/MyAccount'))

/* Kliknięcie Sign UP*/
WebUI.click(findTestObject('Object Repository/PHPTRAVELS_Main/SignUp'))

/* Uzupełnienie Pola FirstName*/
WebUI.setText(findTestObject('Object Repository/PHPTRAVELS_Register/Firstname'), FirstName3)

/* Uzupełnienie Pola LastName*/
WebUI.setText(findTestObject('Object Repository/PHPTRAVELS_Register/Lastname'), LastName3)

/* Uzupełnienie Pola Phone Number*/
WebUI.setText(findTestObject('Object Repository/PHPTRAVELS_Register/Phone'), Phone3)

/* Uzupełnienie Pola Email*/
WebUI.setText(findTestObject('Object Repository/PHPTRAVELS_Register/Email'), Email3)

/* Uzupełnienie Pola Password*/
WebUI.setEncryptedText(findTestObject('Object Repository/PHPTRAVELS_Register/Password'), Password3)

/* Uzupełnienie Pola Confirm Password*/
WebUI.setEncryptedText(findTestObject('Object Repository/PHPTRAVELS_Register/ConfirmPassword'), ConfirmPassword3)

/* Wcisniecie przycisku SignUP*/
WebUI.click(findTestObject('Object Repository/PHPTRAVELS_Register/Button_SignUp'))